"""
Implementation of Luo Shu block cipher

Reference:
[1] Gavin, J., & Smover, V. (2025). Traditional-Chinese-Culture-Inspired Block Cipher with High Diffusion
"""

class Luo_Shu:
    order = [4, 9, 2, 3, 5, 7, 8, 1, 6]
    inv_order = [8, 3, 4, 1, 5, 9, 6, 7, 2]
    sbox = bytearray.fromhex("38d6180ec6a4474a97a1a279e3f9610bc3fa08325f734f6cbe687bb34c1b8d3c63f5e8d8cbcfbcc19a3f6f9f70ca604930e68690c81fe56e8e002e36ea915d922d6befc9dfacf7209b9958b8741642f3b5892cda1287e1adff199e8027b68f5365de242a788295093448d233e23d55bb0d6a8a6dab0259012b56dc1472b01537ce8bb439af83108826f2408498c25bdb46517ea0a3d48543dde03a17d9aa234dfe2144c51a319d2fa5a771545c5ec441b7b1f0c0051c667f2977cc57fd4e13285af4d15096d752d3bdee9c7af8eb933bd06981032245e40a7ca9f662a83ebf7d67ec0c1de74bcded94a68c0475fc1efbb2070fd5b976112535baf1c764ae06e9")
    inv_sbox = bytearray.fromhex("397775d3ebb4fef11267d70fe27003f286f654be7b7e4d9b0259a41db5e3ee3547a1d49e62f7885cbfb8637852403aa730a5136b68f83b7f00839acf1f6ddd298aaf4e97a2d59006692f07e51c9fbd16c391c65fab6e79bb4a76c08eac3ead142e0edb20fc60b6e019d171411773372a2caa7c154cecf5b9640bcb1ad8df92b75bd265858b96325587517281ea1e385e333d3fcee866c4088c492848caa65a2b93090a9405a8e9a9dcd99d744557fd847db1f01b82505db04bf4f96f26c818deb3278d10aea304fb34432d24bae68025d0c26ac795f301c5239c538f7a98614499566c0cd63631e422ff3ccde1e7c942b2fa894fc121da46cc0d11efedbca058")
    mode_tag = 0
    key_stream = bytearray(405)

    def __init__(self, message, mode_tag, key=bytearray(9), iv=bytearray(9)):
        self.mode_tag = 0 if mode_tag == 0 else 1
        try: self.message = bytearray(message)
        except: self.message = bytearray(message.encode())
        try: self.key = bytearray(key)[0:9]
        except: self.key = bytearray(key.encode())[0:9]
        try: self.iv = bytearray(iv)[0:9]
        except: self.iv = bytearray(iv.encode())[0:9]
        if len(self.key) < 9: self.key+=bytearray(9-len(self.key))
        if len(self.iv) < 9: self.iv+=bytearray(9-len(self.iv))
        if not len(self.message) % 9 == 0: self.message+=bytearray(9-len(self.message)%9)
    
    def rol(self, b, shift):
        shift &= 7
        return ((b << shift) | (b >> (8-shift))) & 0xFF

    def ror(self, b, shift):
        shift &= 7
        return ((b >> shift) | (b << (8-shift))) & 0xFF

    def xor_arrays(self, data, key):
        for i in range(9): data[i] ^= key[i]
        return data

    def swap_with_order(self, data, tag):
        tmp = bytearray(len(data))
        for i in range(9): tmp[i] = data[self.order[i]-1] if tag == 0 else data[self.inv_order[i]-1]
        return tmp
    
    def rol_arrays(self, data, key):
        for i in range(9): data[i] = self.rol(data[i], key[i])
        return data
    
    def ror_arrays(self, data, key):
        for i in range(9): data[i] = self.ror(data[i], key[i])
        return data
    
    def sbox_swap(self, data, sbox):
        for i in range(9): data[i] = sbox[data[i]]
        return data
    
    def inv_sbox_swap(self, data, inv_sbox):
        for i in range(9): data[i] = inv_sbox[data[i]]
        return data

    def Key_Stream_Generate(self):
        self.key_stream[0:9] = self.key
        for i in range(9, 405):
            self.key_stream[i] = ((self.key_stream[i-9] + self.order[i%9]) * sum(self.order)) & 0xFF

    def Encrypt_Block(self, block):
        for r in range(45):
            block = self.xor_arrays(block, self.order)
            block = self.rol_arrays(block, self.key_stream[r*9:(r+1)*9]) if r % 2 == 1 else self.ror_arrays(block, self.key_stream[r*9:(r+1)*9])
            block = self.swap_with_order(block, 0)
            block = self.xor_arrays(block, self.key_stream[r*9:(r+1)*9])
            block = self.rol_arrays(block, self.order) if r % 2 == 0 else self.ror_arrays(block, self.order)
            block = self.sbox_swap(block, self.sbox)
        return block

    def Decrypt_Block(self, block):
        for r in range(44, -1, -1):
            block = self.inv_sbox_swap(block, self.inv_sbox)
            block = self.rol_arrays(block, self.order) if r % 2 == 1 else self.ror_arrays(block, self.order)
            block = self.xor_arrays(block, self.key_stream[r*9:(r+1)*9])
            block = self.swap_with_order(block, 1)
            block = self.rol_arrays(block, self.key_stream[r*9:(r+1)*9]) if r % 2 == 0 else self.ror_arrays(block, self.key_stream[r*9:(r+1)*9])
            block = self.xor_arrays(block, self.order)
        return block
    
    def Encrypt(self):
        self.Key_Stream_Generate()
        if self.mode_tag == 1:
            self.message[0:9] = self.xor_arrays(self.message[0:9], self.iv)
        self.message[0:9] = self.Encrypt_Block(self.message[0:9])
        for i in range(1, len(self.message)//9):
            if self.mode_tag == 1:
                self.message[i*9:(i+1)*9] = self.xor_arrays(self.message[i*9:(i+1)*9], self.message[(i-1)*9:i*9])
            self.message[i*9:(i+1)*9] = self.Encrypt_Block(self.message[i*9:(i+1)*9])
        return self.message
    
    def Decrypt(self):
        self.Key_Stream_Generate()
        for i in range(len(self.message)//9-1, 0, -1):
            self.message[i*9:(i+1)*9] = self.Decrypt_Block(self.message[i*9:(i+1)*9])
            if self.mode_tag == 1:
                self.message[i*9:(i+1)*9] = self.xor_arrays(self.message[i*9:(i+1)*9], self.message[(i-1)*9:i*9])
        self.message[0:9] = self.Decrypt_Block(self.message[0:9])
        if self.mode_tag == 1:
            self.message[0:9] = self.xor_arrays(self.message[0:9], self.iv)
        return self.message
