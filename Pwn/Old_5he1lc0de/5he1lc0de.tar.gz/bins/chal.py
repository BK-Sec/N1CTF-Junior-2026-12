import subprocess

class FlagNotFound(Exception):
    def __str__(self):
        return "FlagNotFound"

class ByteCodeAlreadyUsed(Exception):
    def __str__(self):
        return "ByteCodeAlreadyUsed"
    
class ByteCodeTypesOverLimited(Exception):
    def __str__(self):
        return "ByteCodeTypesOverLimited"

def main():
    blacklist = set()
    flag = bytes()
    with open("/flag", "rb") as f:
        flag = f.readline()
    for i in range(2):
        try:
            user_input = bytes.fromhex(input(f"Enter your shellcode as hex({i}/2):").strip())
            for byte in user_input:
                if byte in blacklist:
                    raise ByteCodeAlreadyUsed

            blacklist = blacklist.union(set(user_input))

            if len(blacklist) >= 16:
                raise ByteCodeTypesOverLimited

            p = subprocess.run(
            ['./chal'],
            capture_output=True,
            input=user_input,
            timeout=2.0,
            )
            if flag not in p.stdout:
                raise FlagNotFound

        except Exception as e:
            print("Error:", e)
            exit()
    print("Well Done.")
    print(p.stdout)
    
main()

