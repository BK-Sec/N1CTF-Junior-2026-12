import uuid

class Database:
    def __init__(self):
        self.users = {}  # username -> password
        self.notes = {}  # username -> {note_id -> {title, content, id}}
        self.sessions = {}  # session_id -> username
    
    def create_user(self, username, password):
        if username in self.users:
            return False
        self.users[username] = password
        self.notes[username] = {}
        return True
    
    def verify_user(self, username, password):
        return self.users.get(username) == password
    
    def get_user_password(self, username):
        return self.users.get(username)

    def create_session(self, username):
        session_id = str(uuid.uuid4())
        self.sessions[session_id] = username
        return session_id
    
    def get_user_by_session(self, session_id):
        return self.sessions.get(session_id)
    
    def get_user_notes(self, username):
        return self.notes.get(username, {})
    
    def create_note(self, username, title, content):
        if username not in self.notes:
            self.notes[username] = {}
        note_id = str(uuid.uuid4())
        self.notes[username][note_id] = {
            'title': title,
            'content': content,
            'id': note_id
        }
        return note_id
    
    def get_note(self, username, note_id):
        return self.notes.get(username, {}).get(note_id)
    
    def update_note(self, username, note_id, title, content):
        if username in self.notes and note_id in self.notes[username]:
            self.notes[username][note_id]['title'] = title
            self.notes[username][note_id]['content'] = content
            return True
        return False
    
    def delete_note(self, username, note_id):
        if username in self.notes and note_id in self.notes[username]:
            del self.notes[username][note_id]
            return True
        return False
    
    def search_notes(self, username, query):
        if not username or username not in self.notes:
            return []
        results = []
        user_notes = self.notes[username]
        for note_id, note in user_notes.items():
            if query in note['title'] or query in note['content']:
                results.append(note_id)       
        return results

db = Database()
