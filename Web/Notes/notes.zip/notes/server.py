import os
import sys
import uuid
from app.database import db
from functools import partial
from app.handlers import RequestHandler
from http.server import ThreadingHTTPServer

PORT = 5000

def init_admin():
    flag = os.environ.get("FLAG", "flag{test}")
    if "FLAG" in os.environ:
        os.environ.pop("FLAG")

    ADMIN_PASSWORD = str(uuid.uuid4())

    db.create_user("admin", ADMIN_PASSWORD)
    db.create_note("admin", "secret", flag)

    print(f"Admin password: {ADMIN_PASSWORD}")
    return

def main():
    init_admin()
    handler = partial(RequestHandler, database=db)
    server = ThreadingHTTPServer(('0.0.0.0', PORT), handler)

    try:
        print(f"Server running at http://localhost:{PORT}")
        server.serve_forever()
    except KeyboardInterrupt:
        print("Shutting down server...")
        server.shutdown()

if __name__ == '__main__':
    sys.stdout.reconfigure(line_buffering=True)
    main()
