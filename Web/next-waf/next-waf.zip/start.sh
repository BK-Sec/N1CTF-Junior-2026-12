#!/usr/bin/env bash
set -euo pipefail

if [ -n "${FLAG:-}" ]; then
  printf "%s\n" "$FLAG" > /flag
  chmod 444 /flag
  echo "[entrypoint] wrote /flag from FLAG"
else
  if [ ! -s /flag ]; then
    echo "FLAG_NOT_SET" > /flag
    chmod 444 /flag
    echo "[entrypoint] FLAG not set, wrote placeholder to /flag"
  else
    echo "[entrypoint] /flag already exists"
  fi
fi

PORT=3000 HOSTNAME=127.0.0.1 NODE_ENV=production npm run start -- --hostname 127.0.0.1 --port 3000 &

exec /usr/local/openresty/bin/openresty -g "daemon off;"
