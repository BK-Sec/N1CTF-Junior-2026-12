import os
from urllib.parse import quote

class UtilsMixin:
    def serve_static(self, path):
        try:
            base_dir = os.path.abspath(os.getcwd())
            file_path = path.lstrip("/")
            abs_file_path = os.path.abspath(os.path.join(base_dir, file_path))
            static_root = os.path.join(base_dir, "static")

            if not abs_file_path.startswith(static_root):
                self.send_error(403, "Forbidden")
                return
            
            if abs_file_path.endswith('.css'):
                content_type = 'text/css'
            elif abs_file_path.endswith('.js'):
                content_type = 'application/javascript'
            else:
                content_type = 'text/plain'

            with open(abs_file_path, 'rb') as f:
                self.send_response(200)
                self.send_header("Content-type", content_type)
                self.end_headers()
                self.wfile.write(f.read())
                
        except FileNotFoundError:
            self.send_error(404, "File not found")
    
    def serve_file(self, filepath):
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                self.send_response(200)
                self.send_header("Content-type", "text/html; charset=utf-8")
                self.end_headers()
                self.wfile.write(f.read().encode('utf-8'))
        except FileNotFoundError:
            self.send_error(404, "File not found")
    
    @staticmethod
    def html_escape(text):
        return (str(text)
                .replace('&', '&amp;')
                .replace('<', '&lt;')
                .replace('>', '&gt;')
                .replace('"', '&quot;')
                .replace("'", '&#x27;'))
    
    @staticmethod
    def url_escape(text):
        return quote(str(text))
