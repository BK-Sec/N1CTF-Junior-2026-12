import json

class NotesMixin:
    def render_notes_page(self, username, note_id, search_query):
        all_notes = self.db.get_user_notes(username)
        if search_query:
            filtered_ids = self.db.search_notes(username, search_query)
            notes_to_show = {nid: all_notes[nid] for nid in filtered_ids if nid in all_notes}
        else:
            notes_to_show = all_notes
        
        notes_html = ""
        current_note = None
        
        for nid, note in notes_to_show.items():
            active_class = "active" if nid == note_id else ""
            title = self.html_escape(note.get('title', 'Untitled'))
            content = note.get('content', '')
            preview = self.html_escape(content[:60] + ('...' if len(content) > 60 else ''))
            
            notes_html += f'''
                <a href="/notes/{nid}" class="note-item {active_class}">
                    <h3>{title}</h3>
                    <p>{preview}</p>
                </a>
            '''
        
        if not notes_html:
            if search_query:
                notes_html = '<div class="loading">No results found</div>'
            else:
                pass
        
        notes_html += '''
            <a href="/notes/new" class="note-item new-note">
                <div class="new-note-icon">+</div>
            </a>
        '''
        
        editor_html = ""
        if note_id == "new":
            editor_html = self.render_note_editor(username, None)
        elif note_id:
            current_note = self.db.get_note(username, note_id)
            if current_note:
                editor_html = self.render_note_editor(username, current_note)
        
        if not editor_html:
            editor_html = '''
                <div class="empty-state">
                    <svg width="120" height="120" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1">
                        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                        <polyline points="14 2 14 8 20 8"></polyline>
                        <line x1="16" y1="13" x2="8" y2="13"></line>
                        <line x1="16" y1="17" x2="8" y2="17"></line>
                        <polyline points="10 9 9 9 8 9"></polyline>
                    </svg>
                    <h3>No note selected</h3>
                    <p>Select a note from the sidebar or create a new one</p>
                </div>
            '''
        
        export_html = ""
        if search_query:
            safe_query = self.url_escape(search_query)
            safe_filename = self.url_escape(f"{username}_search_{search_query}.json")
            export_html = f'''
                <a href="/api/search?q={safe_query}&filename={safe_filename}" 
                   class="btn btn-export" 
                   title="Export results"
                   download>
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                        <polyline points="7 10 12 15 17 10"></polyline>
                        <line x1="12" y1="15" x2="12" y2="3"></line>
                    </svg>
                </a>
            '''
        
        html = f'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Notes</title>
    <link rel="stylesheet" href="/static/css/style.css">
</head>
<body>
    <div class="app-container">
        <aside class="sidebar">
            <div class="sidebar-header">
                <h2>Notes</h2>
            </div>
            
            <form class="search-box" method="GET" action="/notes">
                <input type="text" name="q" placeholder="Search notes..." value="{self.html_escape(search_query)}">
                <button type="submit" class="btn btn-export" title="Search">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <circle cx="11" cy="11" r="8"></circle>
                        <path d="m21 21-4.35-4.35"></path>
                    </svg>
                </button>
                {export_html}
            </form>
            
            <div class="notes-list">
                {notes_html}
            </div>
            
            <div class="sidebar-footer">
                <div class="user-info">
                    <span>{self.html_escape(username)}</span>
                </div>
                <form method="POST" action="/logout" style="display: inline;">
                    <button type="submit" class="btn btn-text">Logout</button>
                </form>
            </div>
        </aside>
        
        <main class="main-content">
            {editor_html}
        </main>
    </div>
</body>
</html>'''
        
        self.send_response(200)
        self.send_header("Content-type", "text/html; charset=utf-8")
        self.end_headers()
        self.wfile.write(html.encode('utf-8'))
    
    def render_note_editor(self, username, note):
        if note:
            note_id = note['id']
            title = self.html_escape(note.get('title', ''))
            content = self.html_escape(note.get('content', ''))
            delete_btn = f'<a href="/notes/{note_id}/delete" class="btn btn-danger" onclick="return confirm(\'Delete this note?\')">Delete</a>'
        else:
            note_id = "new"
            title = ""
            content = ""
            delete_btn = ""
        
        return f'''
            <form method="POST" action="/notes/{note_id}/save" class="note-editor">
                <input type="text" name="title" class="note-title" placeholder="Note Title" value="{title}" required>
                <textarea name="content" class="note-content" placeholder="Start writing..." required>{content}</textarea>
                
                <div class="editor-actions">
                    <button type="submit" class="btn btn-primary">Save</button>
                    {delete_btn}
                    <a href="/notes" class="btn btn-text">Cancel</a>
                </div>
            </form>
        '''
    
    def save_note_handler(self, username, note_id, data):
        title = data.get('title', ['Untitled'])[0]
        content = data.get('content', [''])[0]
        
        if note_id == "new":
            new_id = self.db.create_note(username, title, content)
            redirect_url = f"/notes/{new_id}"
        else:
            self.db.update_note(username, note_id, title, content)
            redirect_url = f"/notes/{note_id}"
        
        self.send_response(302)
        self.send_header("Location", redirect_url)
        self.end_headers()
    
    def delete_note_handler(self, username, note_id):
        self.db.delete_note(username, note_id)
        
        self.send_response(302)
        self.send_header("Location", "/notes")
        self.end_headers()
    
    def search_notes_json(self, username, search_query):
        if search_query:
            note_ids = self.db.search_notes(username, search_query)
            all_notes = self.db.get_user_notes(username)
            results = [all_notes[nid] for nid in note_ids if nid in all_notes]
        else:
            all_notes = self.db.get_user_notes(username)
            results = list(all_notes.values())
        
        response_data = {
            'query': search_query,
            'found': len(results),
            'results': results
        }
        
        if results:
            self.send_response(200)
        else:
            self.send_error(404, "No notes found")
            return
        
        self.send_header("Content-type", "application/json")
        self.end_headers()
        self.wfile.write(json.dumps(response_data, indent=2).encode())
    
    def export_notes(self, username, search_query, filename):
        if search_query:
            results = self.db.search_notes(username, search_query)
        else:
            self.send_error(400, "Search query required")
            return
        
        export_data = {
            'query': search_query,
            'total': len(results),
            'results': results
        }
        
        self.send_response(200)
        
        try:
            self.send_header('Content-Disposition', f'attachment; filename="{filename}"')
        except ValueError:
            pass
        
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Content-type", "application/json")
        self.end_headers()
        self.wfile.write(json.dumps(export_data, indent=2).encode())
