const express = require('express');
const bodyParser = require('body-parser');
const session = require('cookie-session');
const addressparser = require('nodemailer/lib/addressparser');
const { env } = require('node:process');
const { randomUUID } = require('node:crypto');

const app = express();
const PORT = 5000;
const FLAG = env.FLAG || "flag{test}";
const ADMIN_EMAIL = "admin@admin.com";
const ADMIN_USERNAME = "Administrator";
const USERS = [];

USERS.push({
    username: ADMIN_USERNAME,
    email: ADMIN_EMAIL,
    password: randomUUID(),
    inbox: []
});
console.log(`Admin password: ${USERS[0].password}`);

app.set('view engine', 'ejs');
app.use(bodyParser.urlencoded({ extended: true }));
app.use(session({
    name: 'session',
    keys: randomUUID().split('-'),
    maxAge: 24 * 60 * 60 * 1000
}));


app.get('/', (req, res) => {
    const username = req.session.user;
    if (username) {
        const user = USERS.find(u => u.username === username);
        if (!user) {
            req.session = null;
            return res.redirect('/');
        }
        const allUsers = USERS.map(u => ({ username: u.username, email: u.email }));
        return res.render('index', { page: 'dashboard', user, usersList: allUsers, error: null });
    }
    res.render('index', { page: 'login', error: null });
});

app.post('/register', (req, res) => {
    const { username, password } = req.body;

    if (!username || !password) {
        return res.render('index', { page: 'login', error: "Username and password required." });
    }

    const invalidChars = [' ',',','"',"'",'\\','/','`',';','%','<', '>','[',']','{','}','|',':'];
    for (const char of invalidChars) {
        if (username.includes(char)) {
            return res.render('index', { page: 'login', error: "Username contains invalid characters." });
        }
    }
    if (username.toLowerCase().includes("admin")) {
        return res.render('index', { page: 'login', error: "Username contains invalid characters." });
    }
    if (USERS.find(u => u.username === username)) {
        return res.render('index', { page: 'login', error: "Username already taken." });
    }

    const generatedEmail = `${username}@test.com`;
    const newUser = {
        username: username, 
        email: generatedEmail,
        password: password,
        inbox: []
    };
    
    USERS.push(newUser);
    req.session.user = username;
    res.redirect('/');
});

app.post('/login', (req, res) => {
    const { username, password } = req.body;
    const user = USERS.find(u => u.username === username && u.password === password);
    if (user) {
        req.session.user = username;
        res.redirect('/');
    } else {
        res.render('index', { page: 'login', error: "Invalid" });
    }
});

app.get('/logout', (req, res) => {
    req.session = null;
    res.redirect('/');
});

app.post('/send', (req, res) => {
    if (!req.session.user) return res.redirect('/');
    const senderUsername = req.session.user;
    let { recipientUsername, subject, content } = req.body;
    const senderUser = USERS.find(u => u.username === senderUsername);
    const recipientUser = USERS.find(u => u.username === recipientUsername);
    if (!senderUser || !recipientUser) {
        return res.send("Error");
    }

    const rawFrom = `${senderUser.username} <${senderUser.email}>`;
    const parsed = addressparser(rawFrom);
    const len = parsed.length;
    const senderEntry = parsed[len - 1];
    console.log(senderEntry);
    if (!senderEntry) {
        return res.send("Error");
    }

    const resolvedEmail = senderEntry.address;
    const resolvedUsername = senderEntry.name;
    let finalContent = content;
    let finalSubject = subject;

    if (resolvedEmail === ADMIN_EMAIL && resolvedUsername === ADMIN_USERNAME) {
        finalContent += `\n\nAdmin's flag: ${FLAG}`;
    }

    recipientUser.inbox.unshift({
        from: resolvedUsername,
        subject: finalSubject,
        content: finalContent,
        time: new Date().toLocaleTimeString()
    });

    res.redirect('/');
});

app.listen(PORT, () => {
    console.log(`running at http://localhost:${PORT}`);
});