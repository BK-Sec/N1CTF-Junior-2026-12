import { Database } from "bun:sqlite";

export interface User {
    id: number;
    username: string;
    password: string;
    role: string;
    secret: string;
}

const db = new Database("sqlite.db");

db.query(`
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE,
        password TEXT,
        role TEXT,
        secret TEXT
    )
`).run();

const check = db.query("SELECT count(*) as count FROM users").get() as { count: number };
if (check.count === 0) {
    console.log("[DB] Seeding database...");
    const insert = db.prepare("INSERT INTO users (username, password, role, secret) VALUES ($u, $p, $r, $s)");
    
    insert.run({
        $u: "admin",
        $p: crypto.randomUUID(),
        $r: "admin",
        $s: "System Access Granted"
    });

    insert.run({
        $u: "guest",
        $p: "guest",
        $r: "user",
        $s: "System Access Denied"
    });
}

export function getUserSync(username: string): User | null {
    return db.query("SELECT * FROM users WHERE username = $u").get({ $u: username }) as User | null;
}

export async function verifyPasswordAsync(username: string, passwordInput: string): Promise<boolean> {
    return new Promise((resolve, reject) => {
        const workerScript = `
        import { Database } from "bun:sqlite";
        declare var self: Worker;

        self.onmessage = (event) => {
            const { username, password } = event.data;
            const db = new Database("sqlite.db", { readonly: true });
            
            try {
                const query = "SELECT password FROM users WHERE username = $u";
                
                const result = db.query(query).get({ $u: username });

                const isValid = result && result.password === password;
                
                self.postMessage({ success: true, isValid });
            } catch (e) {
                self.postMessage({ success: false, error: String(e) });
            } finally {
                db.close();
            }
        };
        `;

        const blob = new Blob([workerScript], { type: "application/javascript" });
        const worker = new Worker(URL.createObjectURL(blob));

        worker.onmessage = (e) => {
            worker.terminate();
            if (e.data.success) {
                resolve(e.data.isValid);
            } else {
                reject(new Error(e.data.error));
            }
        };

        worker.onerror = (e) => {
            worker.terminate();
            reject(e);
        };

        worker.postMessage({ username, password: passwordInput });
    });
}
