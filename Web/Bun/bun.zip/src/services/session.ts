interface SessionData {
    id: string;
    username: string;
    isAuthenticated: boolean;
    createdAt: number;
    metadata?: any;
}

const sessionStore = new Map<string, SessionData>();

export const SessionService = {
    init(id: string, username: string) {
        sessionStore.set(id, {
            id,
            username,
            isAuthenticated: false,
            createdAt: Date.now(),
            metadata: {} 
        });
        return sessionStore.get(id);
    },

    get(id: string) {
        return sessionStore.get(id);
    },

    update(id: string, updates: Partial<SessionData>) {
        const current = sessionStore.get(id);
        if (!current) return null;
        
        const updated = { ...current, ...updates };
        sessionStore.set(id, updated);
        return updated;
    }
};
