from http import cookies

def get_current_user(handler, db):
    if "Cookie" in handler.headers:
        c = cookies.SimpleCookie(handler.headers["Cookie"])
        if "session" in c:
            session_id = c["session"].value
            return db.get_user_by_session(session_id)
    return None

def set_session_cookie(handler, session_id):
    handler.send_header("Set-Cookie", f"session={session_id}; Path=/; HttpOnly")

class AuthMixin:
    def require_auth(self):
        user = get_current_user(self, self.db)
        if not user:
            self.send_response(302)
            self.send_header("Location", "/")
            self.end_headers()
            return None
        return user
    
    def handle_auth(self, data):
        username = data.get('username', [''])[0]
        password = data.get('password', [''])[0]
        action = data.get('action', [''])[0]
        
        if action == "register":
            if self.db.create_user(username, password):
                self.db.create_note(username, "Welcome", "This is your first note")
                session_id = self.db.create_session(username)
                
                self.send_response(302)
                set_session_cookie(self, session_id)
                self.send_header("Location", "/notes")
                self.end_headers()
            else:
                self.send_error(400, "User already exists")
        
        elif action == "login":
            if self.db.verify_user(username, password):
                session_id = self.db.create_session(username)
                
                self.send_response(302)
                set_session_cookie(self, session_id)
                self.send_header("Location", "/notes")
                self.end_headers()
            else:
                self.send_error(403, "Invalid credentials")
