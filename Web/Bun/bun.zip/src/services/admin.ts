import { $ } from "bun";
import { SessionService } from "./session";
import { getUserSync } from "../db";
import { deepMerge, parseParams } from "../utils";

const adminConfig = {
    theme: {
        color: "blue",
        darkMode: false
    },
    analytics: {
        enabled: true
    }
};

export async function handleAdmin(req: Request): Promise<Response> {
    const url = new URL(req.url);

    const authHeader = req.headers.get("Authorization");
    let sessionId = authHeader?.startsWith("Bearer ") ? authHeader.split(" ")[1] : null;

    if (!sessionId) {
        sessionId = url.searchParams.get("sessionId");
    }

    if (!sessionId) {
        return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const session = SessionService.get(sessionId);
    if (!session || !session.isAuthenticated) {
        return Response.json({ error: "Session invalid" }, { status: 403 });
    }

    const user = getUserSync(session.username);
    if (user?.role !== "admin") {
        return Response.json({ error: "Forbidden" }, { status: 403 });
    }

    if (url.pathname === "/api/admin/config" && req.method === "POST") {
        try {
            const rawBody = await req.text();
            const updates = parseParams(rawBody);
            
            deepMerge(adminConfig, updates);
            
            return Response.json({ msg: "Config updated", config: adminConfig });
        } catch (e) {
            return Response.json({ error: String(e) }, { status: 500 });
        }
    }

    if (url.pathname === "/api/admin/diagnose" && req.method === "POST") {
        try {
            const body = await req.json();
            const { tool, target } = body; 
            
            const tools: any = {
                ping: "ping -c 1",
                uptime: "uptime",
                date: "date"
            };
            
            const selectedTool = tools[tool];

            if (!selectedTool) {
                return Response.json({ error: "Invalid tool" }, { status: 400 });
            }

            const output = await $`${selectedTool} ${target || ''}`.text();
            
            return Response.json({ output });
        } catch (e) {
            return Response.json({ error: String(e) }, { status: 500 });
        }
    }

    return Response.json({ error: "Not Found" }, { status: 404 });
}
