import { SessionService } from "./session";
import { getUserSync, verifyPasswordAsync } from "../db";

export async function handleAuth(req: Request): Promise<Response> {
    const url = new URL(req.url);
    
    if (url.pathname === "/api/auth/init" && req.method === "POST") {
        const body = await req.json();
        const { sessionId, username } = body;
        
        if (!sessionId || !username) {
            return Response.json({ error: "Missing parameters" }, { status: 400 });
        }

        const user = getUserSync(username);
        if (!user) {
            return Response.json({ error: "User not found" }, { status: 404 });
        }

        SessionService.init(sessionId, username);
        return Response.json({ status: "pending", msg: "Session initialized. Please verify password." });
    }

    if (url.pathname === "/api/auth/verify" && req.method === "POST") {
        const body = await req.json();
        const { sessionId, password } = body;

        const session = SessionService.get(sessionId);
        if (!session) {
            return Response.json({ error: "Session expired or invalid" }, { status: 401 });
        }

        const isValid = await verifyPasswordAsync(session.username, password);

        if (isValid) {
            const updated = SessionService.update(sessionId, { isAuthenticated: true });
            return Response.json({ success: true, msg: "Authenticated" });
        } else {
            return Response.json({ success: false, error: "Invalid password" }, { status: 403 });
        }
    }

    if (url.pathname === "/api/user/me") {
        const urlParams = new URL(req.url).searchParams;
        const sessionId = urlParams.get("sessionId");
        
        if (!sessionId) return Response.json({ error: "No Session ID" }, { status: 401 });

        const session = SessionService.get(sessionId);
        if (!session || !session.isAuthenticated) {
            return Response.json({ error: "Unauthenticated" }, { status: 403 });
        }

        const user = getUserSync(session.username);
        if (!user) {
            return Response.json({ error: "User not found" }, { status: 404 });
        }
        
        return Response.json({ 
            username: user.username,
            role: user.role,
            secret: user.secret
        });
    }

    return new Response("Not Found", { status: 404 });
}
