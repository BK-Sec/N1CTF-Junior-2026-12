from Crypto.Cipher import ARC4
from random import randbytes
from hashlib import sha1
import os

FLAG = os.getenv("FLAG", "flag{ฅ(^._.^)ฅ}").encode()
key = sha1(FLAG).digest()


def encrypt(plaintext):
    nonce = randbytes(13)
    enc_nonce = ARC4.new(key).encrypt(nonce)
    ciphertext = ARC4.new(ARC4.new(nonce).encrypt(key)).encrypt(plaintext)
    return enc_nonce + ciphertext


open("cat.bin", "wb").write(
    b"".join(encrypt(randbytes(37) if _ else FLAG) for _ in range(0x31415))
)
