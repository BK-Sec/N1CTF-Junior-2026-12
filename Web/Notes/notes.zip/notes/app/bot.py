import time
from playwright.sync_api import sync_playwright

class AdminBot:
    def __init__(self, base_url="http://127.0.0.1:5000"):
        self.base_url = base_url
        self.browser = None
        self.context = None
        self.page = None
    
    def login_as_admin(self, password):
        try:
            print(f"goto {self.base_url}")
            self.page.goto(self.base_url, timeout=30000)
            self.page.wait_for_selector('input[name="username"]', timeout=30000)
            self.page.fill('input[name="username"]', "admin")
            self.page.fill('input[name="password"]', password)
            self.page.click('button[type="submit"]')
            self.page.wait_for_url("**/notes**", timeout=30000)
            print(f"login successful")
            time.sleep(1)
            return True
        except Exception as e:
            print(f"login failed: {str(e)}")
            return False
    
    def visit_url(self, url):
        try:
            print(f"visiting: {url}")
            self.page.goto(url, timeout=60000, wait_until="networkidle")
            print(f"loaded {url}")
            time.sleep(5)
            return True
        except Exception as e:
            print(f"failed: {str(e)}")
            return False
    
    def run(self, target_url, admin_password):
        playwright = None
        try:
            print("starting")
            playwright = sync_playwright().start()
            self.browser = playwright.firefox.launch(headless=True)
            self.context = self.browser.new_context(ignore_https_errors=True)
            self.page = self.context.new_page()
            if not self.login_as_admin(admin_password):
                return False
            if not self.visit_url(target_url):
                return False
            print("over")
            return True
        except Exception as e:
            print(f"failed: {str(e)}")
            return False
        finally:
            if self.page:
                self.page.close()
            if self.browser:
                self.browser.close()
            if playwright:
                playwright.stop()
