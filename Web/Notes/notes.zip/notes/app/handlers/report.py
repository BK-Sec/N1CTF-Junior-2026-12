import threading
from app.bot import AdminBot

class ReportMixin:
    def render_report_page(self):
        self.serve_file("templates/report.html")
    
    def handle_report_submission(self, data):
        target_url = data.get('url', [''])[0]
        
        if not target_url:
            self.send_error(400, "URL is required")
            return
        
        try:
            admin_password = self.db.get_user_password("admin")
            if not admin_password:
                self.send_error(500, "Error, please contact us")
                return

            def run_bot_async():
                bot =AdminBot()
                bot.run(target_url, admin_password)
            
            bot_thread = threading.Thread(target=run_bot_async, daemon=True)
            bot_thread.start()
            
            self.send_response(200)
            self.send_header("Content-type", "text/html; charset=utf-8")
            self.end_headers()
            self.wfile.write(b"Admin will visit your URL soon.")

        except Exception as e:
            print(f"Error: {e}")
            self.send_error(500, f"Failed: {str(e)}")
