#!/bin/sh
if [ -n "$FLAG" ]; then
    echo "$FLAG" > /home/ctf/flag
    export FLAG=not_flag
    FLAG=not_flag
fi

if [ -f /home/ctf/flag ]; then
    chown root:ctf /home/ctf/flag
    chmod 644 /home/ctf/flag
fi

while :; do
    echo "[start.sh] Starting server..."
    /home/ctf/server > /dev/null 2>&1
done &

echo "[start.sh] Starting xinetd..."
exec /usr/sbin/xinetd -dontfork -stayalive
