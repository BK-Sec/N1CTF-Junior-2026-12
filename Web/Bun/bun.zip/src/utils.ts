const blacklist = ['__proto__', 'prototype', 'constructor'];

export const parseParams = (queryString: string) => {
  if (typeof queryString !== 'string') {
    return {};
  }
  const params = new URLSearchParams(queryString.startsWith('?') ? queryString.substring(1) : queryString);
  const result: any = {};
  for (const [key, value] of params.entries()) {
    const path = key.split('.');
    let current = result;
    for (let i = 0; i < path.length; i++) {
        let part = path[i];
        if(blacklist.includes(part)){
            part = 'REDACTED';
        }
        if (i === path.length - 1) {
            current[part] = value;
        } else {
            if (!current[part] || typeof current[part] !== 'object') {
                current[part] = {};
            }
            current = current[part];
        }
    }
  }
  return result;
};

export const deepMerge = (target: any, source: any) => {
  for (const key in source) {
    if (source[key] instanceof Object && key in target) {
      Object.assign(source[key], deepMerge(target[key], source[key]));
    }
  }
  Object.assign(target || {}, source);
  return target;
};
