from LuoShuEncrypt import Luo_Shu
import os, signal

FLAG = os.getenv("FLAG", "flag{ฅ(^._.^)ฅ}")

signal.alarm(42)
cipher = Luo_Shu(message := os.urandom(31415), 9, os.urandom(26), os.urandom(5))
assert input(f"{cipher.Encrypt().hex()}\n{cipher.Encrypt().hex()}\n") == message.hex()
print(FLAG)
