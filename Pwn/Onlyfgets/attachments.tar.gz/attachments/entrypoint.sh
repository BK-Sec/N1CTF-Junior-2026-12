#!/bin/sh

echo "$FLAG" > /home/ctf/onlyfgets/flag.txt
chmod 440 /home/ctf/onlyfgets/flag.txt

socat TCP-LISTEN:8889,reuseaddr,fork EXEC:/home/ctf/onlyfgets/run,stderr
