export default function Page() {
  return (
    <main style={styles.container}>
      <header style={styles.header}>
        <h1 style={styles.title}>My Blog</h1>
        <p style={styles.subtitle}>记录一些前端与后端的技术思考</p>
      </header>

      <section style={styles.post}>
        <h2 style={styles.postTitle}>Next.js Server Components 简介</h2>
        <p style={styles.meta}>发表于 2026-01-11 · 分类：Web Security</p>

        <p style={styles.paragraph}>
          Next.js 的 App Router 引入了 React Server Components（RSC），
          允许开发者在服务端执行组件逻辑，从而减少前端 JavaScript 体积。
        </p>

        <blockquote style={styles.quote}>
          Server Components 使得我们可以将数据获取和渲染逻辑放在服务器端，
          只将必要的 HTML 发送到客户端，提升性能和用户体验。
        </blockquote>

        <p style={styles.paragraph}>
          通过 RSC，Next.js 应用可以更高效地加载页面，减少不必要的网络请求，
          并且更好地利用服务器资源来处理复杂的计算任务。
        </p>
      </section>

      <footer style={styles.footer}>
        <span>© 2026 My Blog</span>
      </footer>
    </main>
  );
}

const styles = {
  container: {
    maxWidth: "760px",
    margin: "0 auto",
    padding: "40px 20px",
    fontFamily:
      "-apple-system, BlinkMacSystemFont, Segoe UI, Roboto, Helvetica, Arial",
    lineHeight: 1.7,
    color: "#222",
  },
  header: {
    borderBottom: "1px solid #eee",
    marginBottom: 32,
    paddingBottom: 16,
  },
  title: {
    margin: 0,
    fontSize: 32,
    letterSpacing: "-0.5px",
  },
  subtitle: {
    marginTop: 8,
    color: "#666",
    fontSize: 14,
  },
  post: {
    marginBottom: 48,
  },
  postTitle: {
    fontSize: 24,
    marginBottom: 8,
  },
  meta: {
    fontSize: 13,
    color: "#888",
    marginBottom: 24,
  },
  paragraph: {
    marginBottom: 16,
  },
  quote: {
    margin: "24px 0",
    paddingLeft: 16,
    borderLeft: "4px solid #ddd",
    color: "#555",
    fontStyle: "italic",
  },
  footer: {
    display: "flex",
    justifyContent: "space-between",
    borderTop: "1px solid #eee",
    paddingTop: 16,
    fontSize: 13,
    color: "#888",
  },
};
