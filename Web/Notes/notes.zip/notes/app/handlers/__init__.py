from urllib.parse import parse_qs, urlparse
from http.server import BaseHTTPRequestHandler
from .utils import UtilsMixin
from .auth import AuthMixin
from .notes import NotesMixin
from .report import ReportMixin

class RequestHandler(BaseHTTPRequestHandler, UtilsMixin, AuthMixin, NotesMixin, ReportMixin):

    CSP_POLICY = "script-src 'none'; object-src 'none';"
    
    def __init__(self, *args, database=None, **kwargs):
        self.db = database
        super().__init__(*args, **kwargs)
    
    def send_response(self, code, message=None):
        super().send_response(code, message)
        self.send_header("Content-Security-Policy", self.CSP_POLICY)

    def do_GET(self):
        parsed_url = urlparse(self.path)
        path = parsed_url.path
        query = parse_qs(parsed_url.query)
        
        # Static
        if path.startswith("/static/"):
            self.serve_static(path)
            return
        
        # Root
        if path == "/":
            self.serve_file("templates/login.html")
            return
        
        # Notes
        if path == "/notes" or path.startswith("/notes/"):
            user = self.require_auth()
            if not user:
                return
            path_parts = path.strip("/").split("/")
            
            if len(path_parts) == 1:  # /notes
                search_query = query.get('q', [''])[0]
                self.render_notes_page(user, None, search_query)
            elif path_parts[1] == "new":  # /notes/new
                self.render_notes_page(user, "new", "")
            elif path_parts[1] and len(path_parts) == 2:  # /notes/{id}
                note_id = path_parts[1]
                self.render_notes_page(user, note_id, "")
            elif len(path_parts) == 3 and path_parts[2] == "delete":  # /notes/{id}/delete
                note_id = path_parts[1]
                self.delete_note_handler(user, note_id)
            return
        
        # Report
        if path == "/report":
            self.render_report_page()
            return
        
        # Search
        if path == "/api/search":
            user = self.require_auth()
            if not user:
                return
            search_query = query.get('q', [''])[0]
            filename = query.get('filename', [''])[0]
            if filename and search_query:
                self.export_notes(user, search_query, filename)
            else:
                self.send_error(400, "Bad Request")
            return
        
        self.send_error(404, "Page not found")
    
    def do_POST(self):
        parsed_url = urlparse(self.path)
        path = parsed_url.path
        content_length = int(self.headers.get('content-length', 0))
        if content_length > 0:
            raw_data = self.rfile.read(content_length).decode('utf-8')
            post_data = parse_qs(raw_data, keep_blank_values=1)
        else:
            post_data = {}
        
        # Authentication
        if path == "/auth":
            self.handle_auth(post_data)
            return
        
        # Logout
        if path == "/logout":
            self.send_response(302)
            self.send_header("Set-Cookie", "session=; Path=/; Max-Age=0")
            self.send_header("Location", "/")
            self.end_headers()
            return
        
        # Submit Report
        if path == "/submit-report":
            self.handle_report_submission(post_data)
            return
        
        # Save
        if path.startswith("/notes/") and path.endswith("/save"):
            user = self.require_auth()
            if not user:
                return
            path_parts = path.strip("/").split("/")
            note_id = path_parts[1] if len(path_parts) >= 2 else None
            self.save_note_handler(user, note_id, post_data)
            return
        
        self.send_error(404, "Not found")
