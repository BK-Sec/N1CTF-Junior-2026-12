from LuoShuEncrypt import Luo_Shu
import os, signal

FLAG = os.getenv("FLAG", "flag{ฅ(^._.^)ฅ}")

signal.alarm(99)
for _ in range(9):
    cipher = Luo_Shu(message := os.urandom(99), 9, os.urandom(9), os.urandom(9))
    assert input(f"{cipher.Encrypt().hex()}\n{cipher.Encrypt().hex()}\n") == message.hex()
print(FLAG)
