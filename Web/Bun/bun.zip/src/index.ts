import { handleAdmin } from "./services/admin";
import { handleAuth } from "./services/auth";

const server = Bun.serve({
  port: 3000,
  async fetch(req) {
    const url = new URL(req.url)
    
    if (url.pathname.startsWith("/api/auth") || url.pathname.startsWith("/api/user")) {
        return handleAuth(req);
    }

    if (url.pathname.startsWith("/api/admin")) {
        return handleAdmin(req);
    }

    if (url.pathname === "/" || url.pathname === "/index.html") {
        return new Response(Bun.file("src/index.html"));
    }

    return new Response("Not Found", { status: 404 });
  },
});

console.log(`Listening on http://localhost:${server.port}`);
